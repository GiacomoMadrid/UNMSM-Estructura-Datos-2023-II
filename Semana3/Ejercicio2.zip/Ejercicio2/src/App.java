
import controller.MainController;
import model.Employee;
import model.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Luis
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List lista = new List();
        lista.append(new Employee("123elt", "Luis La Torre", "Service", 2000, 100, 10));
        MainController controller = new MainController(lista);
        controller.run();
    }
    
}
